export const NotFoundPage = () => {
    return (
        <>
            <img src="	https://miro.medium.com/max/1400/1*zBFBJktPD3_z0S_35kO5Hg.gif" alt="page not found" />

        </>
    )
}